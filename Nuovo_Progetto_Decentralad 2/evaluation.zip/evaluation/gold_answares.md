## Q1
Domanda: <Chi è il professore di Programmazione?>
Gold: <Il professore di Programmazione è Roberto Tonelli>
Come l’ho ottenuta: <22esima riga quarta colonna del file Professori.csv>


## Q2
Domanda: <Quali lezioni si svolgono il Martedì del primo anno?>
Gold: <9:00-11:00 Matematica Discreta>
Come l’ho ottenuta: <3° riga 2,3,4,6 colonna del file Lezioni.csv>


## Q3
Domanda: <Chi è l'ingegnante di Ingegneria del Software e quando si tengono le lezioni del corso di Ingegneria del Software?>
Gold: <L'insegnante di Ingegneria del Software è Maria Ilaria Lunesu, le lezioni iniziano dalle 14:00 alle 16:00 di Mercoledì>
Come l’ho ottenuta: <17esima riga seconda, quarta colonna del file Professori.csv, 15esima riga, 2, 3, 4, 6 colonna del file Lezioni.csv>


## Q4
Domanda: <In quale aula si tiene il corso di Fisica e chi è il professore di questo corso corso?>
Gold: <La lezione di fisica si terrà Mercoledì dalle 14:00 alle 16:00 nell'Aula Magna di Fisica, il professore è Ciriaco Goddi>
Come l’ho ottenuta: <8 riga seconda, terza, quarta, settima colonna del file Lezioni.csv, 14esima riga, 2, 4 colonna del file Professori.csv>


## Q5
Domanda: <Quale corso insegna Mirko Marras e a che ora?>
Gold: <Mirko Marras insegna nel corso di Deep Learning, il lunedì dalle 14:00 alle 16:00>
Come l’ho ottenuta: <19 riga seconda, quarta colonna del file Professori.csv, 13esima riga, 2, 3, 4, 6 colonna del file Lezioni.csv>